# recently-viewed-magento2
Show customers recently viewed products
